# NEAR Intents Dashboard

Live, self-updating dashboard tracking all NEAR Intents swap activity — deployed on Vercel with MongoDB Atlas.

## What It Tracks

- **All intent orders** — every swap flowing through NEAR Intents 1Click API
- **Order sizes & direction** — from/to tokens, chains, USD values
- **Per-pair analytics** — click any pair to drill down into its top 50 trades
- **Size distribution** — avg, median, P75, P90, P95, min, max order sizes
- **Chain flow** — which chains are sending/receiving the most volume
- **Referral breakdown** — who's driving the most volume
- **Top 50 trades** — filterable by 1h / 24h / 7d / 30d / all-time

## Architecture

```
Vercel (Next.js)
├── Dashboard UI ──────── React + Recharts
├── API Routes ────────── /api/stats, /api/trades, /api/pairs, etc.
├── Cron Job (1min) ───── /api/cron → fetches new txs from Explorer API
└── MongoDB Atlas ─────── Persistent storage for all transactions
```

## Deploy to Vercel (5 minutes)

### Step 1: Get your API key

Apply for a NEAR Intents Explorer API JWT:
**https://docs.google.com/forms/d/e/1FAIpQLSdrSrqSkKOMb_a8XhwF0f7N5xZ0Y5CYgyzxiAuoC2g4a2N68g/viewform**

### Step 2: Set up MongoDB Atlas (free tier)

1. Go to **https://cloud.mongodb.com** → Create a free cluster
2. Create a database user (username + password)
3. Whitelist `0.0.0.0/0` in Network Access (allows Vercel serverless)
4. Copy your connection string: `mongodb+srv://user:pass@cluster.mongodb.net/...`

### Step 3: Push to GitHub

```bash
git init
git add .
git commit -m "NEAR Intents Dashboard"
git remote add origin https://github.com/YOUR_USER/near-intents-dashboard.git
git push -u origin main
```

### Step 4: Deploy to Vercel

1. Go to **https://vercel.com/new** → Import your GitHub repo
2. Add environment variables in the Vercel dashboard:

| Variable | Value |
|---|---|
| `MONGODB_URI` | `mongodb+srv://user:pass@cluster.mongodb.net/?retryWrites=true&w=majority` |
| `MONGODB_DB` | `near_intents` |
| `NEAR_INTENTS_JWT` | Your Explorer API JWT token |
| `CRON_SECRET` | Any random string (optional, secures cron endpoint) |

3. Click **Deploy**

The Vercel cron job runs every minute and fetches the latest transactions automatically.

### Step 5: Backfill historical data

```bash
# Locally (one-time, to seed your DB with history)
cp .env.local.example .env.local
# Edit .env.local with your real values

npm install
MONGODB_URI="mongodb+srv://..." NEAR_INTENTS_JWT="..." node scripts/backfill.mjs --pages 50
```

This fetches ~50,000 historical transactions. Takes ~5 minutes due to rate limits.

## Pair Drill-Down

Click any pair name (highlighted in green) anywhere in the dashboard:
- In the **Pairs Analytics** table
- In the **Top Trades** table  
- In the **Live Feed**
- In the **Treemap visualization**

A modal opens showing that pair's **top 50 trades by size** with full details including chain routing, amounts, referral, and timing.

## API Endpoints

All endpoints are serverless functions running on Vercel:

| Route | Description |
|---|---|
| `GET /api/health` | DB connection status & tx count |
| `GET /api/stats` | Overview KPIs (1h/24h/7d/all-time volumes, size percentiles) |
| `GET /api/trades?period=24h&pair=SOL/BTC&limit=50` | Top trades, filterable by pair |
| `GET /api/pairs?period=24h&limit=50` | Per-pair volume, count, avg/median/max |
| `GET /api/chains?period=24h` | Origin & destination chain breakdowns |
| `GET /api/volume?hours=24` | Hourly volume for chart data |
| `GET /api/referrals?period=24h` | Referral volume rankings |
| `GET /api/cron` | Trigger data fetch (called by Vercel Cron) |

## Local Development

```bash
npm install
cp .env.local.example .env.local
# Fill in your MongoDB URI and JWT token
npm run dev
```

Visit http://localhost:3000. The cron doesn't run locally — manually hit http://localhost:3000/api/cron to trigger a fetch.

## Rate Limits

The Explorer API allows 1 request per 5 seconds. The cron fetches 2 pages per minute (well within limits). The backfill script includes automatic rate limiting with 5.5s delays.
