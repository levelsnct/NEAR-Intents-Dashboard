"use client";

import { useState, useEffect, useCallback } from "react";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  AreaChart, Area, CartesianGrid, Cell, Treemap,
} from "recharts";
import Link from "next/link";

// ─── Theme ──────────────────────────────────────────────────────────────────
const C = {
  bg: "#0B0E14", card: "#111820", border: "#1E2A38",
  text: "#E2E8F0", muted: "#64748B", accent: "#00EC97",
  red: "#EF4444", amber: "#F59E0B", purple: "#8B5CF6",
  mono: "'JetBrains Mono', monospace",
  sans: "'Plus Jakarta Sans', -apple-system, system-ui, sans-serif",
};

const CHAIN_COLORS = {
  eth: "#627EEA", near: "#00EC97", sol: "#9945FF", btc: "#F7931A",
  arb: "#28A0F0", base: "#0052FF", tron: "#FF0000", bsc: "#F3BA2F",
  pol: "#8247E5", op: "#FF0420", avax: "#E84142", sui: "#4DA2FF",
  zec: "#ECB244", ton: "#0088CC", doge: "#C2A633", xrp: "#23292F",
  bera: "#FFA500", gnosis: "#04795B",
};

const STATUS_COLORS = {
  SUCCESS: C.accent, FAILED: C.red, REFUNDED: C.purple, PROCESSING: C.amber,
};

// ─── Formatters ─────────────────────────────────────────────────────────────
const fmt = (n) => {
  if (n == null) return "—";
  if (n >= 1e6) return `$${(n / 1e6).toFixed(2)}M`;
  if (n >= 1e3) return `$${(n / 1e3).toFixed(1)}K`;
  return `$${Number(n).toFixed(2)}`;
};
const fmtN = (n) => (n == null ? "—" : Number(n).toLocaleString());
const ago = (ts) => {
  if (!ts) return "—";
  const d = Date.now() / 1000 - ts;
  if (d < 60) return `${Math.floor(d)}s`;
  if (d < 3600) return `${Math.floor(d / 60)}m`;
  if (d < 86400) return `${Math.floor(d / 3600)}h`;
  return `${Math.floor(d / 86400)}d`;
};

// ─── Tiny Components ────────────────────────────────────────────────────────
function Stat({ label, value, sub, accent, icon }) {
  return (
    <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 12, padding: "18px 22px", position: "relative", overflow: "hidden" }}>
      {accent && <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 2, background: `linear-gradient(90deg, ${C.accent}, transparent)` }} />}
      <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 6 }}>
        {icon && <span style={{ fontSize: 14, opacity: 0.5 }}>{icon}</span>}
        <span style={{ fontSize: 11, color: C.muted, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.06em" }}>{label}</span>
      </div>
      <div style={{ fontSize: 26, fontWeight: 700, color: accent ? C.accent : C.text, fontFamily: C.mono, letterSpacing: "-0.02em" }}>{value}</div>
      {sub && <div style={{ fontSize: 11, color: C.muted, marginTop: 4 }}>{sub}</div>}
    </div>
  );
}

function Badge({ status }) {
  const c = STATUS_COLORS[status] || C.muted;
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 4, padding: "2px 8px", borderRadius: 6, fontSize: 10, fontWeight: 700, background: `${c}15`, color: c, border: `1px solid ${c}25` }}>
      <span style={{ width: 5, height: 5, borderRadius: "50%", background: c }} />
      {status}
    </span>
  );
}

function ChainBadge({ chain }) {
  const c = CHAIN_COLORS[chain] || C.muted;
  return (
    <span style={{ padding: "2px 7px", borderRadius: 4, fontSize: 10, fontWeight: 700, background: `${c}18`, color: c, textTransform: "uppercase", fontFamily: C.mono }}>{chain}</span>
  );
}

function PeriodPicker({ value, onChange }) {
  return (
    <div style={{ display: "flex", gap: 3, background: C.bg, borderRadius: 8, padding: 3 }}>
      {["1h", "24h", "7d", "30d", "all"].map((p) => (
        <button key={p} onClick={() => onChange(p)} style={{
          padding: "4px 12px", borderRadius: 6, border: "none", cursor: "pointer",
          fontSize: 11, fontWeight: 700, fontFamily: C.mono,
          background: value === p ? C.accent : "transparent",
          color: value === p ? C.bg : C.muted,
        }}>{p}</button>
      ))}
    </div>
  );
}

function Section({ title, sub, right, children }) {
  return (
    <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 12, padding: 24 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 16, paddingBottom: 12, borderBottom: `1px solid ${C.border}` }}>
        <div>
          <h2 style={{ fontSize: 16, fontWeight: 700, color: C.text, margin: 0 }}>{title}</h2>
          {sub && <p style={{ fontSize: 11, color: C.muted, margin: "3px 0 0" }}>{sub}</p>}
        </div>
        {right}
      </div>
      {children}
    </div>
  );
}

function TT({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: "#1A2332", border: `1px solid ${C.border}`, borderRadius: 8, padding: "8px 12px", boxShadow: "0 8px 32px rgba(0,0,0,0.4)" }}>
      <p style={{ fontSize: 10, color: C.muted, margin: 0 }}>{label}</p>
      {payload.map((p, i) => (
        <p key={i} style={{ fontSize: 12, color: p.color || C.accent, margin: "3px 0 0", fontWeight: 600, fontFamily: C.mono }}>
          {p.name}: {p.name.toLowerCase().includes("vol") ? fmt(p.value) : fmtN(p.value)}
        </p>
      ))}
    </div>
  );
}

// ─── Pair Detail Modal ──────────────────────────────────────────────────────
function PairModal({ pair, period, onClose }) {
  const [trades, setTrades] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!pair) return;
    setLoading(true);
    fetch(`/api/trades?pair=${encodeURIComponent(pair)}&period=${period}&limit=50`)
      .then((r) => r.json())
      .then((d) => { setTrades(d.trades || []); setLoading(false); })
      .catch(() => setLoading(false));
  }, [pair, period]);

  if (!pair) return null;

  return (
    <div onClick={onClose} style={{
      position: "fixed", inset: 0, zIndex: 999,
      background: "rgba(0,0,0,0.7)", backdropFilter: "blur(8px)",
      display: "flex", alignItems: "center", justifyContent: "center",
      padding: 24,
    }}>
      <div onClick={(e) => e.stopPropagation()} style={{
        background: C.card, border: `1px solid ${C.border}`, borderRadius: 16,
        width: "100%", maxWidth: 1000, maxHeight: "85vh", overflow: "auto",
        boxShadow: "0 24px 80px rgba(0,0,0,0.6)",
      }}>
        {/* Modal Header */}
        <div style={{
          padding: "20px 28px", borderBottom: `1px solid ${C.border}`,
          display: "flex", justifyContent: "space-between", alignItems: "center",
          position: "sticky", top: 0, background: C.card, zIndex: 1,
        }}>
          <div>
            <h2 style={{ fontSize: 22, fontWeight: 800, color: C.text, margin: 0, fontFamily: C.mono }}>{pair}</h2>
            <p style={{ fontSize: 12, color: C.muted, margin: "4px 0 0" }}>Top 50 trades by size • {period}</p>
          </div>
          <button onClick={onClose} style={{
            width: 36, height: 36, borderRadius: 10, border: `1px solid ${C.border}`,
            background: C.bg, color: C.muted, cursor: "pointer", fontSize: 18,
            display: "flex", alignItems: "center", justifyContent: "center",
          }}>✕</button>
        </div>

        {/* Stats Row */}
        {trades && trades.length > 0 && (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, padding: "16px 28px" }}>
            <Stat label="Trades" value={fmtN(trades.length)} icon="📊" />
            <Stat label="Largest" value={fmt(trades[0]?.sizeUsd)} accent icon="🏆" />
            <Stat label="Avg Size" value={fmt(trades.reduce((s, t) => s + (t.sizeUsd || 0), 0) / trades.length)} icon="📏" />
            <Stat label="Total Vol" value={fmt(trades.reduce((s, t) => s + (t.sizeUsd || 0), 0))} icon="💰" />
          </div>
        )}

        {/* Trades Table */}
        <div style={{ padding: "0 28px 24px" }}>
          {loading ? (
            <div style={{ textAlign: "center", padding: 40, color: C.muted }}>
              <div style={{ fontSize: 24, animation: "pulse 1.5s infinite" }}>◆</div>
              <div style={{ marginTop: 8, fontSize: 12 }}>Loading trades...</div>
            </div>
          ) : !trades || trades.length === 0 ? (
            <div style={{ textAlign: "center", padding: 40, color: C.muted, fontSize: 13 }}>No trades found for this pair in the selected period.</div>
          ) : (
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr>
                  {["#", "From → To", "Size (USD)", "From Chain", "To Chain", "Status", "Referral", "When"].map((h) => (
                    <th key={h} style={{
                      textAlign: h === "Size (USD)" ? "right" : "left",
                      padding: "10px 14px", fontSize: 10, color: C.muted, fontWeight: 700,
                      textTransform: "uppercase", letterSpacing: "0.06em",
                      borderBottom: `1px solid ${C.border}`, fontFamily: C.mono,
                    }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {trades.map((t, i) => (
                  <tr key={i} style={{ borderBottom: `1px solid ${C.border}08` }}>
                    <td style={{ padding: "10px 14px", fontFamily: C.mono, color: C.muted, fontWeight: 600, fontSize: 12 }}>{i + 1}</td>
                    <td style={{ padding: "10px 14px", fontSize: 12, fontFamily: C.mono, color: C.muted }}>
                      {t.amountInFormatted || "—"} → {t.amountOutFormatted || "—"}
                    </td>
                    <td style={{
                      padding: "10px 14px", textAlign: "right", fontFamily: C.mono, fontWeight: 700, fontSize: 14,
                      color: t.sizeUsd >= 100000 ? C.amber : t.sizeUsd >= 10000 ? C.accent : C.text,
                    }}>{fmt(t.sizeUsd)}</td>
                    <td style={{ padding: "10px 14px" }}><ChainBadge chain={t.originChainId} /></td>
                    <td style={{ padding: "10px 14px" }}><ChainBadge chain={t.destinationChainId} /></td>
                    <td style={{ padding: "10px 14px" }}><Badge status={t.status} /></td>
                    <td style={{ padding: "10px 14px", fontSize: 11, color: C.muted }}>{t.referral || "—"}</td>
                    <td style={{ padding: "10px 14px", fontSize: 11, color: C.muted, fontFamily: C.mono }}>{ago(t.createdAtTimestamp)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Main Dashboard ─────────────────────────────────────────────────────────
export default function Dashboard() {
  const [overview, setOverview]   = useState(null);
  const [topTrades, setTopTrades] = useState([]);
  const [pairs, setPairs]         = useState([]);
  const [hourly, setHourly]       = useState([]);
  const [chains, setChains]       = useState({});
  const [referrals, setReferrals] = useState([]);
  const [period, setPeriod]       = useState("24h");
  const [tab, setTab]             = useState("overview");
  const [lastUpdate, setLastUpdate] = useState(null);
  const [isLive, setIsLive]       = useState(false);
  const [selectedPair, setSelectedPair] = useState(null);

  const load = useCallback(async () => {
    try {
      const [s, t, p, v, ch, r] = await Promise.all([
        fetch("/api/stats").then((r) => r.json()),
        fetch(`/api/trades?limit=50&period=${period}`).then((r) => r.json()),
        fetch(`/api/pairs?limit=50&period=${period}`).then((r) => r.json()),
        fetch("/api/volume?hours=24").then((r) => r.json()),
        fetch(`/api/chains?period=${period}`).then((r) => r.json()),
        fetch(`/api/referrals?period=${period}`).then((r) => r.json()),
      ]);
      setOverview(s);
      setTopTrades(t.trades || []);
      setPairs(p.pairs || []);
      setHourly(v.data || []);
      setChains(ch);
      setReferrals(r.referrals || []);
      setLastUpdate(new Date());
      setIsLive(true);
    } catch (err) {
      console.error("Fetch error:", err);
    }
  }, [period]);

  useEffect(() => { load(); const iv = setInterval(load, 20000); return () => clearInterval(iv); }, [load]);

  const tabs = [
    { id: "overview", label: "Overview" },
    { id: "trades", label: "Top Trades" },
    { id: "pairs", label: "Pair Analytics" },
    { id: "flow", label: "Chain Flow" },
  ];

  const o = overview || {};

  return (
    <div style={{ minHeight: "100vh", background: C.bg, color: C.text, fontFamily: C.sans }}>
      <style>{`
        * { box-sizing: border-box; margin: 0; padding: 0; }
        ::-webkit-scrollbar { width: 5px; height: 5px; }
        ::-webkit-scrollbar-track { background: ${C.bg}; }
        ::-webkit-scrollbar-thumb { background: ${C.border}; border-radius: 3px; }
        @keyframes pulse { 0%,100% { opacity:1; } 50% { opacity:0.3; } }
        @keyframes fadeIn { from { opacity:0; transform:translateY(6px); } to { opacity:1; transform:translateY(0); } }
        .fin { animation: fadeIn .25s ease-out; }
        table { width:100%; border-collapse:collapse; }
        tr:hover td { background: ${C.border}25; }
      `}</style>

      {/* Header */}
      <header style={{
        borderBottom: `1px solid ${C.border}`, padding: "14px 28px",
        display: "flex", justifyContent: "space-between", alignItems: "center",
        background: `${C.card}DD`, backdropFilter: "blur(12px)",
        position: "sticky", top: 0, zIndex: 100,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 30, height: 30, borderRadius: 8, background: `linear-gradient(135deg, ${C.accent}, ${C.accent}60)`, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 800, fontSize: 15, color: C.bg }}>N</div>
          <div>
            <h1 style={{ fontSize: 15, fontWeight: 700, letterSpacing: "-0.02em" }}>NEAR Intents Dashboard</h1>
            <span style={{ fontSize: 10, color: C.muted }}>Live Intent & Order Flow Tracker</span>
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
            <span style={{ width: 6, height: 6, borderRadius: "50%", background: isLive ? C.accent : C.red, boxShadow: isLive ? `0 0 8px ${C.accent}` : `0 0 8px ${C.red}`, animation: isLive ? "pulse 2s infinite" : "none" }} />
            <span style={{ fontSize: 10, color: C.muted, fontFamily: C.mono }}>{isLive ? "LIVE" : "CONNECTING"}</span>
          </div>
          {lastUpdate && <span style={{ fontSize: 10, color: C.muted, fontFamily: C.mono }}>{lastUpdate.toLocaleTimeString()}</span>}
        </div>
      </header>

      {/* Nav */}
      <nav style={{ padding: "0 28px", borderBottom: `1px solid ${C.border}`, display: "flex", background: `${C.card}80` }}>
        {tabs.map((t) => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{
            padding: "12px 18px", border: "none", cursor: "pointer", fontSize: 12, fontWeight: 600,
            background: "transparent", color: tab === t.id ? C.accent : C.muted,
            borderBottom: `2px solid ${tab === t.id ? C.accent : "transparent"}`,
          }}>{t.label}</button>
        ))}
        <div style={{ flex: 1 }} />
        <div style={{ display: "flex", alignItems: "center" }}>
          <PeriodPicker value={period} onChange={setPeriod} />
        </div>
      </nav>

      {/* Content */}
      <main style={{ padding: "20px 28px", maxWidth: 1500, margin: "0 auto" }} className="fin">

        {!overview ? (
          <div style={{ textAlign: "center", padding: 80, color: C.muted }}>
            <div style={{ fontSize: 28, animation: "pulse 1.5s infinite", color: C.accent }}>◆</div>
            <div style={{ marginTop: 12, fontSize: 13 }}>Connecting to NEAR Intents...</div>
            <div style={{ marginTop: 4, fontSize: 11 }}>Make sure the database has data. Run the cron endpoint or backfill script first.</div>
          </div>
        ) : (
          <>
            {/* ─── OVERVIEW ─── */}
            {tab === "overview" && (
              <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(185px, 1fr))", gap: 14 }}>
                  <Stat label="24h Volume" value={fmt(o.h24?.volume)} sub={`${fmtN(o.h24?.trades)} trades`} accent icon="◆" />
                  <Stat label="1h Volume" value={fmt(o.h1?.volume)} sub={`${fmtN(o.h1?.trades)} trades`} icon="⏱" />
                  <Stat label="7d Volume" value={fmt(o.d7?.volume)} sub={`${fmtN(o.d7?.trades)} trades`} icon="📅" />
                  <Stat label="All-Time" value={fmt(o.allTime?.volume)} sub={`${fmtN(o.allTime?.trades)} total`} icon="∞" />
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(145px, 1fr))", gap: 10 }}>
                  <Stat label="Avg Order (24h)" value={fmt(o.h24?.avgSize)} />
                  <Stat label="Median Order" value={fmt(o.h24?.medianSize)} />
                  <Stat label="Max Trade" value={fmt(o.h24?.maxSize)} />
                  <Stat label="P75" value={fmt(o.h24?.p75)} />
                  <Stat label="P90" value={fmt(o.h24?.p90)} />
                  <Stat label="P95" value={fmt(o.h24?.p95)} />
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 14 }}>
                  <Section title="Hourly Volume" sub="Last 24 hours">
                    <ResponsiveContainer width="100%" height={240}>
                      <AreaChart data={hourly}>
                        <defs><linearGradient id="vg" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={C.accent} stopOpacity={0.3}/><stop offset="100%" stopColor={C.accent} stopOpacity={0}/></linearGradient></defs>
                        <CartesianGrid strokeDasharray="3 3" stroke={C.border} />
                        <XAxis dataKey="hour" tick={{ fill: C.muted, fontSize: 9 }} axisLine={false} tickLine={false} tickFormatter={(v) => v?.slice(11, 16) || v} />
                        <YAxis tick={{ fill: C.muted, fontSize: 9 }} axisLine={false} tickLine={false} tickFormatter={(v) => v >= 1e6 ? `${(v/1e6).toFixed(1)}M` : `${(v/1e3).toFixed(0)}K`} />
                        <Tooltip content={<TT />} />
                        <Area type="monotone" dataKey="volume" name="Volume" stroke={C.accent} fill="url(#vg)" strokeWidth={2} />
                      </AreaChart>
                    </ResponsiveContainer>
                  </Section>

                  <Section title="Status Breakdown">
                    {o.statuses && Object.entries(o.statuses).map(([st, count]) => {
                      const total = Object.values(o.statuses).reduce((a, b) => a + b, 0);
                      const pct = total ? ((count / total) * 100).toFixed(1) : 0;
                      return (
                        <div key={st} style={{ marginBottom: 14 }}>
                          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
                            <span style={{ fontSize: 11, fontWeight: 700, color: STATUS_COLORS[st] || C.muted }}>{st}</span>
                            <span style={{ fontSize: 11, color: C.muted, fontFamily: C.mono }}>{fmtN(count)} ({pct}%)</span>
                          </div>
                          <div style={{ height: 5, background: `${C.border}50`, borderRadius: 3 }}>
                            <div style={{ height: "100%", borderRadius: 3, width: `${pct}%`, background: STATUS_COLORS[st] || C.muted, transition: "width 0.4s" }} />
                          </div>
                        </div>
                      );
                    })}
                  </Section>
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
                  <Section title="Top Referrals" sub="By volume">
                    {referrals.slice(0, 8).map((r, i) => (
                      <div key={r.name} style={{ display: "flex", alignItems: "center", gap: 10, padding: "7px 10px", borderRadius: 8, background: i === 0 ? `${C.accent}08` : "transparent" }}>
                        <span style={{ width: 22, height: 22, borderRadius: 5, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 700, background: `${C.accent}15`, color: C.accent, fontFamily: C.mono }}>{i + 1}</span>
                        <span style={{ flex: 1, fontSize: 12, fontWeight: 600 }}>{r.name}</span>
                        <span style={{ fontSize: 11, color: C.muted, fontFamily: C.mono }}>{fmtN(r.trades)} txs</span>
                        <span style={{ fontSize: 12, fontWeight: 700, color: C.accent, fontFamily: C.mono }}>{fmt(r.volume)}</span>
                      </div>
                    ))}
                  </Section>

                  <Section title="Live Feed" sub="Most recent swaps">
                    <div style={{ maxHeight: 310, overflowY: "auto" }}>
                      {topTrades.slice(0, 12).map((t, i) => (
                        <div key={i} style={{ display: "flex", alignItems: "center", gap: 8, padding: "7px 8px", borderRadius: 6, background: `${C.border}15`, marginBottom: 4, fontSize: 11 }}>
                          <Badge status={t.status} />
                          <span
                            onClick={() => setSelectedPair(t.pair)}
                            style={{ fontWeight: 700, minWidth: 80, cursor: "pointer", color: C.accent, textDecoration: "underline", textDecorationColor: `${C.accent}40`, textUnderlineOffset: 2 }}
                          >{t.pair}</span>
                          <span style={{ flex: 1, color: C.muted, fontFamily: C.mono, fontSize: 10 }}>{t.amountInFormatted} → {t.amountOutFormatted}</span>
                          <span style={{ fontWeight: 700, color: C.text, fontFamily: C.mono }}>{fmt(t.sizeUsd)}</span>
                          <span style={{ color: C.muted, fontFamily: C.mono, fontSize: 9, minWidth: 30 }}>{ago(t.createdAtTimestamp)}</span>
                        </div>
                      ))}
                    </div>
                  </Section>
                </div>
              </div>
            )}

            {/* ─── TOP TRADES ─── */}
            {tab === "trades" && (
              <Section title="Top 50 Trades by Size" sub={`Period: ${period} • Click any pair to drill down`}>
                <div style={{ overflowX: "auto" }}>
                  <table>
                    <thead>
                      <tr>
                        {["#", "Pair", "From", "To", "Size (USD)", "Src → Dst", "Status", "Referral", "When"].map((h) => (
                          <th key={h} style={{
                            textAlign: h === "Size (USD)" ? "right" : "left",
                            padding: "9px 12px", fontSize: 10, color: C.muted, fontWeight: 700,
                            textTransform: "uppercase", letterSpacing: "0.05em",
                            borderBottom: `1px solid ${C.border}`, fontFamily: C.mono,
                          }}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {topTrades.slice(0, 50).map((t, i) => (
                        <tr key={i}>
                          <td style={{ padding: "10px 12px", fontFamily: C.mono, color: C.muted, fontWeight: 600, fontSize: 11 }}>{i + 1}</td>
                          <td style={{ padding: "10px 12px" }}>
                            <span
                              onClick={() => setSelectedPair(t.pair)}
                              style={{ fontWeight: 800, fontSize: 13, cursor: "pointer", color: C.accent, textDecoration: "underline", textDecorationColor: `${C.accent}40`, textUnderlineOffset: 2 }}
                            >{t.pair}</span>
                          </td>
                          <td style={{ padding: "10px 12px", fontFamily: C.mono, fontSize: 11, color: C.muted }}>{t.amountInFormatted}</td>
                          <td style={{ padding: "10px 12px", fontFamily: C.mono, fontSize: 11, color: C.muted }}>{t.amountOutFormatted}</td>
                          <td style={{
                            padding: "10px 12px", textAlign: "right", fontFamily: C.mono, fontWeight: 700, fontSize: 13,
                            color: t.sizeUsd >= 100000 ? C.amber : t.sizeUsd >= 10000 ? C.accent : C.text,
                          }}>{fmt(t.sizeUsd)}</td>
                          <td style={{ padding: "10px 12px" }}>
                            <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
                              <ChainBadge chain={t.originChainId} />
                              <span style={{ color: C.muted, fontSize: 10 }}>→</span>
                              <ChainBadge chain={t.destinationChainId} />
                            </div>
                          </td>
                          <td style={{ padding: "10px 12px" }}><Badge status={t.status} /></td>
                          <td style={{ padding: "10px 12px", fontSize: 11, color: C.muted }}>{t.referral || "—"}</td>
                          <td style={{ padding: "10px 12px", fontSize: 10, color: C.muted, fontFamily: C.mono }}>{ago(t.createdAtTimestamp)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Section>
            )}

            {/* ─── PAIR ANALYTICS ─── */}
            {tab === "pairs" && (
              <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                <Section title="Pair Volume Distribution" sub={`${period} • Click any pair to see its top trades`}>
                  <ResponsiveContainer width="100%" height={280}>
                    <Treemap
                      data={pairs.slice(0, 20).map((p) => ({ name: p.pair, size: p.totalVolume, vol: fmt(p.totalVolume) }))}
                      dataKey="size" stroke={C.border}
                      content={({ x, y, width, height, name, vol }) => {
                        if (width < 35 || height < 28) return null;
                        return (
                          <g style={{ cursor: "pointer" }} onClick={() => setSelectedPair(name)}>
                            <rect x={x} y={y} width={width} height={height} fill={`${C.accent}20`} stroke={C.border} rx={4} />
                            <text x={x + width / 2} y={y + height / 2 - 7} textAnchor="middle" fill={C.text} fontSize={Math.min(12, width / 8)} fontWeight={700}>{name}</text>
                            <text x={x + width / 2} y={y + height / 2 + 9} textAnchor="middle" fill={C.accent} fontSize={Math.min(10, width / 10)} fontWeight={600}>{vol}</text>
                          </g>
                        );
                      }}
                    />
                  </ResponsiveContainer>
                </Section>

                <Section title="Pair Analytics Table" sub="Click any pair name to drill down into its top trades">
                  <div style={{ overflowX: "auto" }}>
                    <table>
                      <thead>
                        <tr>
                          {["#", "Pair", "Total Volume", "Trades", "Avg Size", "Median", "Max Trade", "Vol Share"].map((h) => (
                            <th key={h} style={{
                              textAlign: ["Total Volume", "Trades", "Avg Size", "Median", "Max Trade", "Vol Share"].includes(h) ? "right" : "left",
                              padding: "9px 12px", fontSize: 10, color: C.muted, fontWeight: 700,
                              textTransform: "uppercase", letterSpacing: "0.05em",
                              borderBottom: `1px solid ${C.border}`, fontFamily: C.mono,
                            }}>{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {(() => {
                          const totalVol = pairs.reduce((s, p) => s + (p.totalVolume || 0), 0) || 1;
                          return pairs.map((p, i) => {
                            const share = ((p.totalVolume / totalVol) * 100).toFixed(1);
                            return (
                              <tr key={p.pair}>
                                <td style={{ padding: "10px 12px", fontFamily: C.mono, color: C.muted, fontWeight: 600, fontSize: 11 }}>{i + 1}</td>
                                <td style={{ padding: "10px 12px" }}>
                                  <span
                                    onClick={() => setSelectedPair(p.pair)}
                                    style={{ fontWeight: 800, fontSize: 13, cursor: "pointer", color: C.accent, textDecoration: "underline", textDecorationColor: `${C.accent}40`, textUnderlineOffset: 2 }}
                                  >{p.pair}</span>
                                </td>
                                <td style={{ padding: "10px 12px", textAlign: "right", fontFamily: C.mono, fontWeight: 700, color: C.accent }}>{fmt(p.totalVolume)}</td>
                                <td style={{ padding: "10px 12px", textAlign: "right", fontFamily: C.mono }}>{fmtN(p.tradeCount)}</td>
                                <td style={{ padding: "10px 12px", textAlign: "right", fontFamily: C.mono, color: C.muted }}>{fmt(p.avgSize)}</td>
                                <td style={{ padding: "10px 12px", textAlign: "right", fontFamily: C.mono, color: C.muted }}>{fmt(p.medianSize)}</td>
                                <td style={{ padding: "10px 12px", textAlign: "right", fontFamily: C.mono, color: C.amber }}>{fmt(p.maxSize)}</td>
                                <td style={{ padding: "10px 12px", textAlign: "right" }}>
                                  <div style={{ display: "flex", alignItems: "center", gap: 6, justifyContent: "flex-end" }}>
                                    <div style={{ width: 50, height: 5, background: `${C.border}50`, borderRadius: 3 }}>
                                      <div style={{ height: "100%", borderRadius: 3, width: `${Math.min(share, 100)}%`, background: C.accent }} />
                                    </div>
                                    <span style={{ fontSize: 10, color: C.muted, fontFamily: C.mono, minWidth: 35 }}>{share}%</span>
                                  </div>
                                </td>
                              </tr>
                            );
                          });
                        })()}
                      </tbody>
                    </table>
                  </div>
                </Section>
              </div>
            )}

            {/* ─── CHAIN FLOW ─── */}
            {tab === "flow" && (
              <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
                  {[["Source Chains", "origins", "originChainId"], ["Destination Chains", "destinations", "destinationChainId"]].map(([title, key]) => (
                    <Section key={key} title={title} sub={`Volume by ${title.toLowerCase()}`}>
                      <ResponsiveContainer width="100%" height={280}>
                        <BarChart data={(chains[key] || []).slice(0, 10)} layout="vertical" margin={{ left: 50 }}>
                          <CartesianGrid strokeDasharray="3 3" stroke={C.border} />
                          <XAxis type="number" tick={{ fill: C.muted, fontSize: 9 }} axisLine={false} tickFormatter={(v) => v >= 1e6 ? `$${(v/1e6).toFixed(1)}M` : `$${(v/1e3).toFixed(0)}K`} />
                          <YAxis type="category" dataKey="chain" tick={{ fill: C.text, fontSize: 11, fontWeight: 600 }} axisLine={false} tickFormatter={(v) => v?.toUpperCase()} width={40} />
                          <Tooltip content={<TT />} />
                          <Bar dataKey="volume" name="Volume" radius={[0, 5, 5, 0]}>
                            {(chains[key] || []).slice(0, 10).map((e, i) => (
                              <Cell key={i} fill={CHAIN_COLORS[e.chain] || C.accent} fillOpacity={0.8} />
                            ))}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </Section>
                  ))}
                </div>

                <Section title="Chain Breakdown" sub="Complete flow analysis">
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
                    {[["ORIGIN CHAINS", "origins"], ["DESTINATION CHAINS", "destinations"]].map(([label, key]) => (
                      <div key={key}>
                        <h3 style={{ fontSize: 12, color: C.muted, marginBottom: 10, fontWeight: 700 }}>{label}</h3>
                        {(chains[key] || []).map((c) => {
                          const maxV = (chains[key] || [])[0]?.volume || 1;
                          return (
                            <div key={c.chain} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 7 }}>
                              <ChainBadge chain={c.chain} />
                              <div style={{ flex: 1, height: 7, background: `${C.border}40`, borderRadius: 4 }}>
                                <div style={{ height: "100%", borderRadius: 4, width: `${(c.volume / maxV) * 100}%`, background: CHAIN_COLORS[c.chain] || C.accent }} />
                              </div>
                              <span style={{ fontSize: 11, fontWeight: 600, fontFamily: C.mono, minWidth: 70, textAlign: "right" }}>{fmt(c.volume)}</span>
                              <span style={{ fontSize: 10, color: C.muted, fontFamily: C.mono, minWidth: 40, textAlign: "right" }}>{fmtN(c.trades)}</span>
                            </div>
                          );
                        })}
                      </div>
                    ))}
                  </div>
                </Section>
              </div>
            )}
          </>
        )}
      </main>

      {/* Pair drill-down modal */}
      <PairModal pair={selectedPair} period={period} onClose={() => setSelectedPair(null)} />

      <footer style={{ padding: "14px 28px", borderTop: `1px solid ${C.border}`, display: "flex", justifyContent: "space-between", fontSize: 10, color: C.muted, marginTop: 32 }}>
        <span>NEAR Intents Dashboard • Powered by Explorer API + MongoDB</span>
        <span>Auto-refresh 20s • Vercel Cron every 1m</span>
      </footer>
    </div>
  );
}
