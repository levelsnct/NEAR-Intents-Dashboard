import { NextResponse } from "next/server";
import { getDb } from "@/lib/mongodb";

const PERIOD_MAP = { "1h": 3600, "24h": 86400, "7d": 604800, "30d": 2592000 };

function median(arr) {
  if (!arr.length) return 0;
  const s = [...arr].sort((a, b) => a - b);
  const mid = Math.floor(s.length / 2);
  return s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
}

export async function GET(req) {
  try {
    const { searchParams } = new URL(req.url);
    const limit  = Math.min(parseInt(searchParams.get("limit") || "50"), 200);
    const period = searchParams.get("period") || "24h";

    const db  = await getDb();
    const col = db.collection("transactions");
    const now = Math.floor(Date.now() / 1000);

    const match = { status: "SUCCESS", sizeUsd: { $gt: 0 } };
    if (period !== "all" && PERIOD_MAP[period]) {
      match.createdAtTimestamp = { $gte: now - PERIOD_MAP[period] };
    }

    const pipeline = [
      { $match: match },
      { $group: {
        _id: "$pair",
        totalVolume: { $sum: "$sizeUsd" },
        tradeCount:  { $sum: 1 },
        avgSize:     { $avg: "$sizeUsd" },
        maxSize:     { $max: "$sizeUsd" },
        minSize:     { $min: "$sizeUsd" },
        lastTrade:   { $max: "$createdAtTimestamp" },
        sizes:       { $push: "$sizeUsd" },
      }},
      { $sort: { totalVolume: -1 } },
      { $limit: limit },
    ];

    const raw = await col.aggregate(pipeline).toArray();

    const pairs = raw.map((p) => ({
      pair: p._id,
      totalVolume: p.totalVolume,
      tradeCount: p.tradeCount,
      avgSize: p.avgSize,
      medianSize: median(p.sizes?.filter(Boolean) || []),
      maxSize: p.maxSize,
      minSize: p.minSize,
      lastTrade: p.lastTrade,
    }));

    return NextResponse.json({ pairs, count: pairs.length, period });
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
