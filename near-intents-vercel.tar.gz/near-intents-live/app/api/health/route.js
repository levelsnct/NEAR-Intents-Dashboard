import { NextResponse } from "next/server";
import { getDb } from "@/lib/mongodb";

export async function GET() {
  try {
    const db = await getDb();
    const count = await db.collection("transactions").countDocuments();
    const meta = await db.collection("meta").findOne({ _id: "last_fetch" });

    return NextResponse.json({
      status: "ok",
      transactions: count,
      lastFetch: meta?.timestamp ? new Date(meta.timestamp).toISOString() : null,
      lastFetchNew: meta?.newTxs ?? null,
    });
  } catch (err) {
    return NextResponse.json({ status: "error", error: err.message }, { status: 500 });
  }
}
