import { NextResponse } from "next/server";
import { getDb } from "@/lib/mongodb";

const PERIOD_MAP = { "1h": 3600, "24h": 86400, "7d": 604800, "30d": 2592000 };

export async function GET(req) {
  try {
    const { searchParams } = new URL(req.url);
    const period = searchParams.get("period") || "24h";
    const db  = await getDb();
    const col = db.collection("transactions");
    const now = Math.floor(Date.now() / 1000);

    const match = { status: "SUCCESS", sizeUsd: { $gt: 0 } };
    if (period !== "all" && PERIOD_MAP[period]) {
      match.createdAtTimestamp = { $gte: now - PERIOD_MAP[period] };
    }

    const mkPipeline = (field) => [
      { $match: match },
      { $group: { _id: `$${field}`, volume: { $sum: "$sizeUsd" }, trades: { $sum: 1 } } },
      { $sort: { volume: -1 } },
    ];

    const [origins, destinations] = await Promise.all([
      col.aggregate(mkPipeline("originChainId")).toArray(),
      col.aggregate(mkPipeline("destinationChainId")).toArray(),
    ]);

    return NextResponse.json({
      origins: origins.map((o) => ({ chain: o._id, volume: o.volume, trades: o.trades })),
      destinations: destinations.map((d) => ({ chain: d._id, volume: d.volume, trades: d.trades })),
      period,
    });
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
