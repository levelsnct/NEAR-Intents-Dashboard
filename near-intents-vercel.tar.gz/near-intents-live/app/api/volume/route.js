import { NextResponse } from "next/server";
import { getDb } from "@/lib/mongodb";

export async function GET(req) {
  try {
    const { searchParams } = new URL(req.url);
    const hours = Math.min(parseInt(searchParams.get("hours") || "24"), 168);
    const db  = await getDb();
    const col = db.collection("transactions");
    const now = Math.floor(Date.now() / 1000);

    const pipeline = [
      { $match: { status: "SUCCESS", createdAtTimestamp: { $gte: now - hours * 3600 }, sizeUsd: { $gt: 0 } } },
      { $group: {
        _id: { $subtract: ["$createdAtTimestamp", { $mod: ["$createdAtTimestamp", 3600] }] },
        volume: { $sum: "$sizeUsd" },
        trades: { $sum: 1 },
        avg: { $avg: "$sizeUsd" },
      }},
      { $sort: { _id: 1 } },
    ];

    const raw = await col.aggregate(pipeline).toArray();

    return NextResponse.json({
      data: raw.map((r) => ({
        timestamp: r._id,
        hour: new Date(r._id * 1000).toISOString().slice(0, 13) + ":00",
        volume: r.volume,
        trades: r.trades,
        avgSize: r.avg,
      })),
      hours,
    });
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
