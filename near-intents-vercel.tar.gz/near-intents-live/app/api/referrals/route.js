import { NextResponse } from "next/server";
import { getDb } from "@/lib/mongodb";

const PERIOD_MAP = { "1h": 3600, "24h": 86400, "7d": 604800, "30d": 2592000 };

export async function GET(req) {
  try {
    const { searchParams } = new URL(req.url);
    const period = searchParams.get("period") || "24h";
    const limit  = Math.min(parseInt(searchParams.get("limit") || "20"), 100);

    const db  = await getDb();
    const col = db.collection("transactions");
    const now = Math.floor(Date.now() / 1000);

    const match = { status: "SUCCESS", referral: { $ne: null, $exists: true } };
    if (period !== "all" && PERIOD_MAP[period]) {
      match.createdAtTimestamp = { $gte: now - PERIOD_MAP[period] };
    }

    const pipeline = [
      { $match: match },
      { $group: { _id: "$referral", volume: { $sum: "$sizeUsd" }, trades: { $sum: 1 } } },
      { $sort: { volume: -1 } },
      { $limit: limit },
    ];

    const raw = await col.aggregate(pipeline).toArray();

    return NextResponse.json({
      referrals: raw.map((r) => ({ name: r._id, volume: r.volume, trades: r.trades })),
      period,
    });
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
