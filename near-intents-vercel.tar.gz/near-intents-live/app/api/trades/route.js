import { NextResponse } from "next/server";
import { getDb } from "@/lib/mongodb";

const PERIOD_MAP = { "1h": 3600, "24h": 86400, "7d": 604800, "30d": 2592000 };

export async function GET(req) {
  try {
    const { searchParams } = new URL(req.url);
    const limit  = Math.min(parseInt(searchParams.get("limit") || "50"), 200);
    const period = searchParams.get("period") || "24h";
    const pair   = searchParams.get("pair") || null;

    const db  = await getDb();
    const col = db.collection("transactions");
    const now = Math.floor(Date.now() / 1000);

    const filter = { status: "SUCCESS", sizeUsd: { $gt: 0 } };
    if (period !== "all" && PERIOD_MAP[period]) {
      filter.createdAtTimestamp = { $gte: now - PERIOD_MAP[period] };
    }
    if (pair) {
      filter.pair = decodeURIComponent(pair);
    }

    const trades = await col
      .find(filter, {
        projection: {
          _id: 0, depositAddressAndMemo: 1, pair: 1, fromSymbol: 1, toSymbol: 1,
          originChainId: 1, destinationChainId: 1,
          amountInFormatted: 1, amountOutFormatted: 1,
          amountInUsdNum: 1, amountOutUsdNum: 1, sizeUsd: 1,
          status: 1, createdAt: 1, createdAtTimestamp: 1, referral: 1, intentHashes: 1,
        },
      })
      .sort({ sizeUsd: -1 })
      .limit(limit)
      .toArray();

    return NextResponse.json({ trades, count: trades.length, period, pair });
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
