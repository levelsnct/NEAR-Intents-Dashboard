import { NextResponse } from "next/server";
import { getDb } from "@/lib/mongodb";

function median(arr) {
  if (!arr.length) return 0;
  const s = [...arr].sort((a, b) => a - b);
  const mid = Math.floor(s.length / 2);
  return s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
}

function percentile(arr, p) {
  if (!arr.length) return 0;
  const s = [...arr].sort((a, b) => a - b);
  const idx = Math.min(Math.floor(s.length * p), s.length - 1);
  return s[idx];
}

export async function GET() {
  try {
    const db = await getDb();
    const col = db.collection("transactions");
    const now = Math.floor(Date.now() / 1000);

    const windows = {
      h1:  now - 3600,
      h24: now - 86400,
      d7:  now - 604800,
    };

    // Run all aggregations in parallel
    const mkPipeline = (since) => [
      { $match: { status: "SUCCESS", createdAtTimestamp: { $gte: since }, sizeUsd: { $gt: 0 } } },
      { $group: {
        _id: null,
        volume: { $sum: "$sizeUsd" },
        trades: { $sum: 1 },
        avg: { $avg: "$sizeUsd" },
        max: { $max: "$sizeUsd" },
        min: { $min: "$sizeUsd" },
        sizes: { $push: "$sizeUsd" },
      }},
    ];

    const allTimePipeline = [
      { $match: { status: "SUCCESS", sizeUsd: { $gt: 0 } } },
      { $group: {
        _id: null,
        volume: { $sum: "$sizeUsd" },
        trades: { $sum: 1 },
        avg: { $avg: "$sizeUsd" },
      }},
    ];

    const statusPipeline = [
      { $group: { _id: "$status", count: { $sum: 1 } } },
    ];

    const [r1h, r24h, r7d, rAll, rStatus] = await Promise.all([
      col.aggregate(mkPipeline(windows.h1)).toArray(),
      col.aggregate(mkPipeline(windows.h24)).toArray(),
      col.aggregate(mkPipeline(windows.d7)).toArray(),
      col.aggregate(allTimePipeline).toArray(),
      col.aggregate(statusPipeline).toArray(),
    ]);

    const s1h  = r1h[0]  || {};
    const s24h = r24h[0] || {};
    const s7d  = r7d[0]  || {};
    const sAll = rAll[0] || {};

    const sizes24h = (s24h.sizes || []).filter(Boolean);

    return NextResponse.json({
      h1:  { volume: s1h.volume || 0, trades: s1h.trades || 0 },
      h24: {
        volume: s24h.volume || 0,
        trades: s24h.trades || 0,
        avgSize: s24h.avg || 0,
        medianSize: median(sizes24h),
        maxSize: s24h.max || 0,
        minSize: s24h.min || 0,
        p75: percentile(sizes24h, 0.75),
        p90: percentile(sizes24h, 0.90),
        p95: percentile(sizes24h, 0.95),
      },
      d7:  { volume: s7d.volume || 0, trades: s7d.trades || 0, avgSize: s7d.avg || 0 },
      allTime: { volume: sAll.volume || 0, trades: sAll.trades || 0, avgSize: sAll.avg || 0 },
      statuses: Object.fromEntries(rStatus.map((s) => [s._id, s.count])),
      updatedAt: new Date().toISOString(),
    });
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
