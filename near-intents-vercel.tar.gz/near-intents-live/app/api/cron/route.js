import { NextResponse } from "next/server";
import { fetchAndStore } from "@/lib/fetcher";
import { ensureIndexes } from "@/lib/mongodb";

export const maxDuration = 60; // allow up to 60s for Vercel Pro

export async function GET(req) {
  // Verify cron secret if configured (recommended for production)
  const authHeader = req.headers.get("authorization");
  if (
    process.env.CRON_SECRET &&
    authHeader !== `Bearer ${process.env.CRON_SECRET}`
  ) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    await ensureIndexes();

    // Fetch last 2 pages (most recent 1000 txs) to catch new ones
    const result = await fetchAndStore({ pages: 2 });

    return NextResponse.json({
      ok: true,
      ...result,
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    console.error("Cron fetch error:", err);
    return NextResponse.json(
      { ok: false, error: err.message },
      { status: 500 }
    );
  }
}
