/**
 * NEAR Intents Dashboard - Historical Backfill Script
 * 
 * Seeds MongoDB with historical transactions from the Explorer API.
 * Run once before deploying, or periodically to catch up.
 *
 * Usage:
 *   MONGODB_URI=mongodb+srv://... NEAR_INTENTS_JWT=... node scripts/backfill.mjs --pages 50
 */

import { MongoClient } from "mongodb";

const MONGO_URI = process.env.MONGODB_URI || "mongodb://localhost:27017";
const MONGO_DB  = process.env.MONGODB_DB  || "near_intents";
const JWT       = process.env.NEAR_INTENTS_JWT;
const API_BASE  = "https://explorer.near-intents.org/api/v0";
const RATE_DELAY = 5500; // 5.5s between requests

// ─── Normalization (inlined to keep script standalone) ──────────────────────

const KNOWN = {
  "a0b86991c6218b36c1d19d4a2e9eb0ce3606eb48": "USDC",
  "dac17f958d2ee523a2206206994597c13d831ec7": "USDT",
  "17208628f84f5d6ad33f0da3bbbeb27ffcb398eac501a31bd6ad2011e36133a1": "USDC",
  "2260fac5e5542a773aa44fbcfedf7c193bc2c599": "WBTC",
  "c02aaa39b223fe8d0a0e5c4f27ead9083c756cc2": "WETH",
  "wrap.near": "NEAR",
};

const CHAINS = ["eth-","base-","arb-","sol-","btc-","ton-","doge-","xrp-","zec-","gnosis-","bera-","bsc-","pol-","tron-","sui-","op-","avax-","cardano-","stellar-","aptos-","ltc-","monad-","scroll-","starknet-","bch-","xlayer-","plasma-","adi-"];

function chain(a) {
  if (!a) return "unknown";
  const l = a.toLowerCase();
  for (const p of CHAINS) { if (l.includes(p)) return p.replace("-",""); }
  if (l.includes("wrap.near") || (l.includes("near") && !l.includes("omft"))) return "near";
  return "near";
}

function sym(a) {
  if (!a) return "???";
  const l = a.toLowerCase();
  for (const [k,v] of Object.entries(KNOWN)) { if (l.includes(k)) return v; }
  if (l.includes("usdt")) return "USDT";
  if (l.includes("usdc")) return "USDC";
  if (l.includes("sol") && !l.includes("usdc")) return "SOL";
  if (l.includes("btc") && !l.includes("wbtc")) return "BTC";
  if (l.includes("doge")) return "DOGE";
  if (l.includes("xrp")) return "XRP";
  if (l.includes("zec")) return "ZEC";
  if (l.includes("ton")) return "TON";
  if (l.includes("ltc")) return "LTC";
  if (l.includes("avax")) return "AVAX";
  if (l.includes("near") && !l.includes("omft")) return "NEAR";
  const parts = a.split(":");
  return parts.length > 1 ? parts[1].slice(0,8).toUpperCase() : a.slice(0,8).toUpperCase();
}

function normalize(tx) {
  const inUsd  = parseFloat(tx.amountInUsd || 0) || 0;
  const outUsd = parseFloat(tx.amountOutUsd || 0) || 0;
  const fs = sym(tx.originAsset), ts = sym(tx.destinationAsset);
  return {
    ...tx,
    amountInUsdNum: inUsd, amountOutUsdNum: outUsd,
    originChainId: chain(tx.originAsset), destinationChainId: chain(tx.destinationAsset),
    fromSymbol: fs, toSymbol: ts,
    pair: `${fs}/${ts}`,
    sizeUsd: Math.max(inUsd, outUsd),
    fetchedAt: new Date().toISOString(),
  };
}

// ─── Main ───────────────────────────────────────────────────────────────────

async function main() {
  if (!JWT) { console.error("Set NEAR_INTENTS_JWT env var"); process.exit(1); }

  const maxPages = parseInt(process.argv.find(a => a.startsWith("--pages"))?.split("=")[1] || process.argv[process.argv.indexOf("--pages") + 1] || "20");

  const client = new MongoClient(MONGO_URI);
  await client.connect();
  const col = client.db(MONGO_DB).collection("transactions");

  await col.createIndex({ depositAddressAndMemo: 1 }, { unique: true, sparse: true });
  await col.createIndex({ createdAtTimestamp: -1 });
  await col.createIndex({ sizeUsd: -1 });
  await col.createIndex({ pair: 1, createdAtTimestamp: -1 });

  console.log(`◆ NEAR Intents Backfill — up to ${maxPages} pages`);
  console.log(`  MongoDB: ${MONGO_URI.replace(/\/\/[^@]+@/, "//***@")}`);
  console.log("─".repeat(60));

  let totalNew = 0, totalUp = 0;

  for (let page = 1; page <= maxPages; page++) {
    const params = new URLSearchParams({
      perPage: "1000", page: String(page),
      statuses: "SUCCESS,PROCESSING,FAILED,REFUNDED",
    });

    const res = await fetch(`${API_BASE}/transactions-pages?${params}`, {
      headers: { Authorization: `Bearer ${JWT}` },
    });

    if (res.status === 429) {
      console.log(`  ⏸ Rate limited on page ${page}, waiting 10s...`);
      await new Promise(r => setTimeout(r, 10000));
      page--; continue;
    }
    if (res.status === 401) { console.error("JWT unauthorized"); break; }
    if (!res.ok) { console.error(`API ${res.status}`); break; }

    const body = await res.json();
    const txs = Array.isArray(body) ? body : (body.transactions || body.data || []);
    if (!txs.length) { console.log("  No more data"); break; }

    const ops = txs.map(tx => ({
      updateOne: {
        filter: { depositAddressAndMemo: tx.depositAddressAndMemo || tx.depositAddress },
        update: { $set: normalize(tx) },
        upsert: true,
      },
    }));

    const r = await col.bulkWrite(ops, { ordered: false });
    totalNew += r.upsertedCount || 0;
    totalUp  += r.modifiedCount || 0;

    const oldest = Math.min(...txs.map(t => t.createdAtTimestamp || Infinity));
    const oldestDate = oldest < Infinity ? new Date(oldest * 1000).toISOString().slice(0,16) : "?";
    console.log(`  Page ${String(page).padStart(3)}: ${txs.length} txs | +${r.upsertedCount} new | oldest: ${oldestDate}`);

    if (txs.length < 1000) break;
    await new Promise(r => setTimeout(r, RATE_DELAY));
  }

  const total = await col.countDocuments();
  console.log("─".repeat(60));
  console.log(`◆ Done! +${totalNew} new, ~${totalUp} updated | Total: ${total.toLocaleString()} docs`);

  await client.close();
}

main().catch(console.error);
